# Electrical Shop Manager Online — हिंदी सेटअप गाइड

## इसमें क्या है
- ईमेल/पासवर्ड लॉगिन (Firebase Authentication)
- कई मोबाइल पर एक ही दुकान का क्लाउड डेटा (Cloud Firestore)
- स्टॉक: पीस/मीटर/बंडल, खरीद और बिक्री रेट, HSN, कम स्टॉक सीमा
- बिक्री, GST की गणना, नमूना इनवॉइस प्रिंट/PDF
- ग्राहक और उधार लेजर / भुगतान रिकॉर्ड
- JSON बैकअप डाउनलोड और इम्पोर्ट
- Android Chrome में PWA की तरह इंस्टॉल करने की सुविधा

## बहुत जरूरी: यह APK नहीं है
यह एक installable web app/PWA प्रोजेक्ट है। इसे HTTPS वेबसाइट पर होस्ट करने के बाद Android Chrome में खोलें → ⋮ मेनू → “Install app” या “Add to Home screen” चुनें। असली APK के लिए Android Studio/Capacitor से अलग Android build बनाना होगा। Firebase config और क्लाउड सेटअप किए बिना लॉगिन काम नहीं करेगा।

## 1. Firebase प्रोजेक्ट बनाएँ
1. https://console.firebase.google.com खोलें और नया प्रोजेक्ट बनाएँ।
2. Project settings → General → Your apps → Web app (`</>`) जोड़ें।
3. Firebase SDK config कॉपी करें।
4. Authentication → Sign-in method → Email/Password चालू करें।
5. Authentication → Users → Add user से दुकान के मालिक का ईमेल और पासवर्ड बनाएँ।
6. Build → Firestore Database → Create database चुनें। Production mode से शुरू करें।
7. Firestore → Rules में `firestore.rules` का पूरा कंटेंट डालकर Publish करें।
8. `index.html` में `firebaseConfig` की छह वैल्यू अपने प्रोजेक्ट की असली वैल्यू से बदलें। `PASTE_...` टेक्स्ट नहीं छोड़ें।

## 2. मालिक को दुकान से जोड़ें
1. Firebase Console → Authentication → Users खोलें और मालिक का UID कॉपी करें।
2. Firestore Data में root collection `users` बनाएँ।
3. उसमें document ID के रूप में वही UID डालें (UID को document ID बनाना जरूरी है)।
4. उस document में string field जोड़ें: `shopId` = `shop001`
5. बाकी अधिकृत मोबाइल/कर्मचारी के लिए Authentication में अलग ईमेल/पासवर्ड बनाएँ। उनके UID के लिए `users/{UID}` document बनाएँ और वही `shopId` = `shop001` रखें।
6. किसी व्यक्ति को हटाते समय उसका Authentication user और `users/{UID}` profile हटाएँ।

**सुरक्षा:** `shopId` किसी अनजान व्यक्ति को न दें। `users` प्रोफाइल लिखने की अनुमति क्लाइंट को नहीं है। कर्मचारी के अधिकार अभी दुकान के सभी रिकॉर्ड पढ़ने/बदलने के हैं; सीमित भूमिकाएँ चाहिए तो Rules और ऐप में role checks जोड़ें। मालिक का Firebase अकाउंट सुरक्षित रखें और 2-step verification सक्षम करें।

## 3. HTTPS होस्टिंग और Android इंस्टॉल
सबसे आसान तरीका Firebase Hosting:
1. कंप्यूटर पर Node.js इंस्टॉल करें, फिर `npm install -g firebase-tools` चलाएँ।
2. इस फ़ोल्डर में टर्मिनल खोलें और चलाएँ: `firebase login`
3. `firebase init hosting` चलाएँ, अपना प्रोजेक्ट चुनें, public directory के लिए इसी प्रोजेक्ट की फ़ाइलों वाला फ़ोल्डर चुनें, single-page app = No चुनें।
4. `firebase.json` में public directory के लिए ये फाइलें शामिल हों: `index.html`, `manifest.json`, `sw.js`, `icon-192.png`, `icon-512.png`; फिर `firebase deploy --only hosting` चलाएँ।
5. Firebase Hosting का HTTPS URL Android Chrome में खोलें → ⋮ → Install app/Add to Home screen।

इस पैकेज में icons शामिल हैं। अगर Hosting setup पहले से है तो सभी फ़ाइलें उसी public directory में रखें।

## 4. कई मोबाइल पर इस्तेमाल
हर मोबाइल पर उसी वेबसाइट को खोलें और संबंधित Firebase Authentication ईमेल/पासवर्ड से लॉगिन करें। एक ही `shopId` वाले यूज़र एक ही स्टॉक, बिक्री, ग्राहक और सेटिंग साझा करेंगे। Firestore listener अपडेट अपने आप दिखाता है। सभी डिवाइसों पर इंटरनेट चाहिए।

## 5. GST और लेखा सावधानी
यह एक शुरुआती ऑपरेशनल टूल है, GST portal filing software नहीं। GST दर चुनने से पहले सही HSN/वर्गीकरण और लागू दर, taxable value, place of supply, invoice serial number, ग्राहक के आवश्यक विवरण, reverse charge/अन्य लागू शर्तें अपने अकाउंटेंट से सत्यापित करें। इस डेमो में invoice ID Firestore document ID है; नियमित GST invoice sequence/पूर्ण वैधानिक fields और tax rounding को production में जोड़वाएँ। वास्तविक बिक्री से पहले परीक्षण करें।

## 6. बैकअप और सीमाएँ
- JSON बैकअप डाउनलोड करें और सुरक्षित जगह पर रखें।
- Firestore automated backups/exports के लिए Google Cloud Billing/permissions लग सकती हैं; Cloud Console में अलग से configure करें।
- ऐप के भीतर इम्पोर्ट रिकॉर्ड जोड़ता है; बार-बार वही बैकअप इम्पोर्ट करने से डुप्लिकेट बन सकते हैं।
- यह शुरुआती scaffold है, स्वतंत्र security audit नहीं। असली ग्राहक/वित्तीय डेटा डालने से पहले परीक्षण करें।
